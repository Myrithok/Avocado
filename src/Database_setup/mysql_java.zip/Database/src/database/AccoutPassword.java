package database;

import java.sql.*;
import java.util.Scanner;

public class AccoutPassword {

	private static final String url = "jdbc:mysql://localhost:3306/UP";

	private static final String user = "root";

	private static final String password = "miwi9226";

	public static void main(String[] args) {
	
		Scanner sc = new Scanner(System.in);
		
		try {
			//1. get a connection to database
			//Service: @127.0.0.1:3306	 
			
			Connection myConn = DriverManager.getConnection(url, user, password);
			System.out.println("connected to Database");
			System.out.println("\n");
			
			Statement Stmt = myConn.createStatement();
			
			char answer;
			
			do {
				System.out.print("AccountID: ");
				String AccountID = sc.next();
			
				String SQL = "SELECT * FROM up WHERE AccountID = '" + AccountID + "'";
			
				ResultSet rs = Stmt.executeQuery(SQL);
			
		    
				if(rs.next()) {
					System.out.println("Account successfully found");
					System.out.println("password: " + rs.getString("Pwd"));
				}
				else {
					System.out.println("Account Do not exist!");
				}
				
				System.out.print("Do you want to search for another account (Y/N): ");
				answer = sc.next().charAt(0);  //
				
			} while(answer == 'Y' || answer == 'y');
		}
			
		
		catch (Exception exc) {
				exc.printStackTrace();
			}
	}
}
